#include "xcortexa9.h"

XCortexa9_Config XCortexa9_ConfigTable[] __attribute__ ((section (".drvcfg_sec"))) = {
	{
		0x27bc86bf  /* xlnx,cpu-clk-freq-hz */
	}
};